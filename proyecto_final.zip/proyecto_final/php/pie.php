</main>
<br>
<footer class="px-2 py-2 fixed-bottom bg-dark">
        <span class="text-muted">CRUD de MySQLi con PHP creado por
            <a class="text-white" href="//parzibyte.me/blog">JHONATHAN CHANAMÉ VARGAS V CICLO DSI</a>
            &nbsp;|&nbsp;
            <a target="_blank" class="text-white" href="php-mysqli">
              
            </a>
        </span>
</footer>
</body>
</html>